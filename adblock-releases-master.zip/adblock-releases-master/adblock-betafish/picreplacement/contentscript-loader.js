'use strict';

/* For ESLint: List any global identifiers used in this file below */
/* global browser */

browser.runtime.sendMessage({ message: 'load_my_adblock' });
