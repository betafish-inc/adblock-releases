import { specificClicker } from "./specificClicker.js";

snippets.specificClicker = specificClicker;

