(function()
{
  module("AdBlock");

  test("Example AdBlock unit tests", function()
  {
    equal(true, false, "AdBlock tests have been written...");
  });
})();
